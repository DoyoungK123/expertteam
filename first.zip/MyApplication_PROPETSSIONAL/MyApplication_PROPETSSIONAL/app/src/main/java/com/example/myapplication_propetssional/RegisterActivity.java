package com.example.myapplication_propetssional;

import android.app.Activity;

public class RegisterActivity extends Activity {
}
